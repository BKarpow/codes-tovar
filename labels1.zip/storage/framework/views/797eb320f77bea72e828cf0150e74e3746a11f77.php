

<?php $__env->startSection('title'); ?> Коды товаров <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="card">
                <div class="card-header">Коды товаров</div>

                <div class="card-body">
                    <div class="my-1">
                        <a href="<?php echo e(route('code.create')); ?>" class="btn btn-primary">
                            + Добавить
                        </a>
                        <!-- /.btn btn-primary -->
                    </div>
                    <!-- /.my-1 -->
                    <?php if($codes->count() > 0): ?>
                    <div class="my-1">
                        <fast></fast>
                    </div>
                    <!-- /.my-1 -->
                    <table class="table table-dark table-responsive table-hover">
                        <thead>
                            <tr>
                                <th>Товар</th>
                                <th>Код</th>
                                <th>Код Н</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <span class="code-text-n">
                                            <?php echo e($code->name); ?>

                                        </span>
                                        <!-- /.code-text-n -->
                                        <div class="mt-1">
                                            <a href="<?php echo e(route('code.edit', ['code'=>$code])); ?> " class="btn btn-warning btn-sm">
                                                Редактировать
                                            </a>
                                            <!-- /.btn btn-warning btn-sm -->
                                        </div>
                                        <!-- /.mt-1 -->
                                          </td>
                                    <td> 
                                        <span class="code-text">
                                            <?php echo e($code->code); ?>

                                        </span>
                                        <!-- /.code-text --> 
                                </td>
                                    <td>
                                        <span class="code-text">
                                            <?php echo e($code->code_n); ?>

                                        </span>
                                        <!-- /.code-text --> 
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?> 
                        <div class="alert alert-secondary">
                            Поки немає кодів...
                        </div>
                        <!-- /.alert alert-secondary -->
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\labels\resources\views/code.blade.php ENDPATH**/ ?>