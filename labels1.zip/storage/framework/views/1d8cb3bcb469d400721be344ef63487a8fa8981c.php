

<?php $__env->startSection('title'); ?> Создать новый код <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Создать новый код</div>

                <div class="card-body">
                    <h2>Форма</h2>
                    <form action="<?php echo e(route('code.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?> 
                        <div class="form-group pt-1">
                            <label for="name">Имя товара</label>
                            <input 
                                type="text"
                                require
                                name="name" 
                                id="name" 
                                placeholder="Товар"
                                class="form-control"
                            >
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="alert alert-warning">
                                    <strong>
                                        <?php echo e($message); ?>

                                    </strong>
                                </div>
                                <!-- /.alert alert-warning -->
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label for="code">Код</label>
                            <input 
                                type="text"
                                require
                                name="code" 
                                id="code" 
                                pattern="^\d+$"
                                placeholder="Код товару"
                                class="form-control code-input"
                            >
                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="alert alert-warning">
                                    <strong>
                                        <?php echo e($message); ?>

                                    </strong>
                                </div>
                                <!-- /.alert alert-warning -->
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label for="code_n">Код Н</label>
                            <input 
                                type="text"
                                name="code_n" 
                                id="code_n" 
                                require
                                pattern="^\d+$"
                                value="0"
                                placeholder="Код товару N"
                                class="form-control code-input"
                            >
                            <?php $__errorArgs = ['code_n'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="alert alert-warning">
                                    <strong>
                                        <?php echo e($message); ?>

                                    </strong>
                                </div>
                                <!-- /.alert alert-warning -->
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label for="price">Цена</label>
                            <input 
                                type="text"
                                name="price" 
                                id="price" 
                                require
                                value="0.0"
                                placeholder="Цена"
                                class="form-control"
                            >
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="alert alert-warning">
                                    <strong>
                                        <?php echo e($message); ?>

                                    </strong>
                                </div>
                                <!-- /.alert alert-warning -->
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group">
                            <label for="price">Описания</label>
                            <textarea 
                            placeholder="Описания товара"
                            maxlength="249" 
                            class="form-control" 
                            name="comment">Просто товар</textarea>
                            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <div class="alert alert-warning">
                                    <strong>
                                        <?php echo e($message); ?>

                                    </strong>
                                </div>
                                <!-- /.alert alert-warning -->
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- /.form-group -->

                        <div class="form-group mt-1">
                            <button class="btn btn-success btn-lg">
                                Создать новый код.
                            </button>
                        </div>
                        <!-- /.form-group -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\labels\resources\views/create.blade.php ENDPATH**/ ?>